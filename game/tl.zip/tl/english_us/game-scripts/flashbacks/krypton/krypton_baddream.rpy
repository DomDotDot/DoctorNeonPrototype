﻿# TODO: Translation updated at 2025-09-28 18:21

# game/game-scripts/flashbacks/krypton/krypton_baddream.rpy:3
translate english_us chapter1_krypton_baddream_12ab6656:

    # narrator "Перед глазами Неон мелькал образ женщины с длинными светлыми и черными волосами, смеющейся и как будто зовущей ее."
    narrator "A vision of a woman with long white and black hair flashed before Neon's eyes, laughing and seemingly calling her."

# game/game-scripts/flashbacks/krypton/krypton_baddream.rpy:8
translate english_us chapter1_krypton_baddream_d543b766:

    # "???" "Неон. Слышишь звонок? Пары закончились. Пошли сегодня в парк?"
    "???" "Heeey Neon. Hear the bell? Classes are over. Wanna go to the park today?"

# game/game-scripts/flashbacks/krypton/krypton_baddream.rpy:9
translate english_us chapter1_krypton_baddream_1f4c4914:

    # "???" "Сегодня как раз хорошая погода для прогулки."
    "???" "I think today's weather is perfect for a nice walk."

